var poeng = 0;

// Alle data i quizen. Spoersmaal, bilder og hva som er riktig svar
quizdata = [
    ["Hvordan er det vanligst aa lage spill naa til dags for amatoerer? Ved aa bruke:", "JavaScript", "Python", "CSS", "Motorer som unity", "C++", "Cobolt", [4]],
    ["Hva er en av fordelene med aa skrive dokumentasjon?", "Lettere aa veldikeholde", "Du bruker mer tid paa pairarbeid og faar mer loenn", "Familien din blir stolt", "Sjefen blir glad", "Alle de tidligere nevnte", "Det er ingen fordeler", [1]],
    ["Hva mangler for at dette objektet skal bli definert? const biler _____ {....}", ":", ";", "=", "|", "-", " ingen ting", [3]],
    ["Hvilke fly er amerikansk?", "Jas-39", "Mig 29", "Su-52", "Spitfire", "P-51", "B-52", [5, 6]],
    [],     
]
    
// Funksjon som oppdaterer alt med data fra arrayet over
function oppdaterQuiz(quizdata, quiznr){    

    document.getElementById("spoersmaal").innerHTML = quizdata[quiznr][0];
    document.getElementById('alt1').innerHTML = quizdata[quiznr][1];
    document.getElementById('alt1').style.filter = "";
    document.getElementById('alt2').innerHTML = quizdata[quiznr][2];
    document.getElementById('alt2').style.filter = "";
    document.getElementById('alt3').innerHTML = quizdata[quiznr][3];
    document.getElementById('alt3').style.filter = "";
    document.getElementById('alt4').innerHTML = quizdata[quiznr][4];
    document.getElementById('alt4').style.filter = "";
    document.getElementById('alt5').innerHTML = quizdata[quiznr][5];
    document.getElementById('alt5').style.filter = "";
    document.getElementById('alt6').innerHTML = quizdata[quiznr][6];
    document.getElementById('alt6').style.filter = "";


    return quiznr;
}

riktig = 0;

// Hva som skjer naar du velger et bilde
function sjekkSvr(quizdata, alt, quiznr){
    if(alt == 0){
        if (quizdata[quiznr][7].includes(alt)){
        }
    }

    if(alt == 1){
        if (quizdata[quiznr][7].includes(alt)){
            poeng = poeng + 1;
            riktig = 1;
        }
    }
    
    if(alt == 2){
        if (quizdata[quiznr][7].includes(alt)){
            poeng = poeng + 1;
            riktig = 1;
        }
    }

    if(alt == 3){
        if (quizdata[quiznr][7].includes(alt)){
            poeng = poeng + 1;
            riktig = 1;
        }
    }

    if(alt == 4){
        if (quizdata[quiznr][7].includes(alt)){
            poeng = poeng + 1;
            riktig = 1;
        }
    }
    
    if(alt == 5){
        if (quizdata[quiznr][7].includes(alt)){
            poeng = poeng + 1;
            riktig = 1;
        }
    }

    if(alt == 6){
        if (quizdata[quiznr][7].includes(alt)){
            poeng = poeng + 1;
            riktig = 1;
        }
    }
}

const start = document.getElementById('start');

const boks = document.getElementById('quiz');

const boks2 = document.getElementById('diagram');

const slutt = document.getElementById('slutt');

const salt1 = document.getElementById('salt1');

const salt2 = document.getElementById('salt2');

const salt3 = document.getElementById('salt3');

const salt4 = document.getElementById('salt4');

const sirkel = document.getElementById('sirkel')

boks2.style.display = 'none';


start.addEventListener('click', () => {

start.style.display = 'none';

boks.style.display = 'flex';

});

// Vis foerste spoersmaal
quiznr = oppdaterQuiz(quizdata, 0);

var svr = 0;

// Hva som skjer naar du trykker paa bilde 1
alt1.addEventListener("click", () => {
    svr = 1;
    document.getElementById("alt1").style.backgroundColor = "grey";
    document.getElementById("alt2").style.backgroundColor = "#ffffff";
    document.getElementById("alt3").style.backgroundColor = "#ffffff";
    document.getElementById("alt4").style.backgroundColor = "#ffffff";
    document.getElementById("alt5").style.backgroundColor = "#ffffff";
    document.getElementById("alt6").style.backgroundColor = "#ffffff";
})

// Hva som skjer naar du trykker paa bilde 2
alt2.addEventListener("click", () => {
    svr = 2;
    document.getElementById("alt1").style.backgroundColor = "#ffffff";
    document.getElementById("alt2").style.backgroundColor = "grey";
    document.getElementById("alt3").style.backgroundColor = "#ffffff";
    document.getElementById("alt4").style.backgroundColor = "#ffffff";
    document.getElementById("alt5").style.backgroundColor = "#ffffff";
    document.getElementById("alt6").style.backgroundColor = "#ffffff";
})

// Hva som skjer naar du trykker paa bilde 3
alt3.addEventListener("click", () => {
    svr = 3;
    document.getElementById("alt1").style.backgroundColor = "#ffffff";
    document.getElementById("alt2").style.backgroundColor = "#ffffff";
    document.getElementById("alt3").style.backgroundColor = "grey";
    document.getElementById("alt4").style.backgroundColor = "#ffffff";
    document.getElementById("alt5").style.backgroundColor = "#ffffff";
    document.getElementById("alt6").style.backgroundColor = "#ffffff";
})

alt4.addEventListener("click", () => {
    svr = 4;
    document.getElementById("alt1").style.backgroundColor = "#ffffff";
    document.getElementById("alt2").style.backgroundColor = "#ffffff";
    document.getElementById("alt3").style.backgroundColor = "#ffffff";
    document.getElementById("alt4").style.backgroundColor = "grey";
    document.getElementById("alt5").style.backgroundColor = "#ffffff";
    document.getElementById("alt6").style.backgroundColor = "#ffffff";
})

// Hva som skjer naar du trykker paa bilde 2
alt5.addEventListener("click", () => {
    svr = 5;
    document.getElementById("alt1").style.backgroundColor = "#ffffff";
    document.getElementById("alt2").style.backgroundColor = "#ffffff";
    document.getElementById("alt3").style.backgroundColor = "#ffffff";
    document.getElementById("alt4").style.backgroundColor = "#ffffff";
    document.getElementById("alt5").style.backgroundColor = "grey";
    document.getElementById("alt6").style.backgroundColor = "#ffffff";
})

// Hva som skjer naar du trykker paa bilde 3
alt6.addEventListener("click", () => {
    svr = 6;
    document.getElementById("alt1").style.backgroundColor = "#ffffff";
    document.getElementById("alt2").style.backgroundColor = "#ffffff";
    document.getElementById("alt3").style.backgroundColor = "#ffffff";
    document.getElementById("alt4").style.backgroundColor = "#ffffff";
    document.getElementById("alt5").style.backgroundColor = "#ffffff";
    document.getElementById("alt6").style.backgroundColor = "grey";
})

neste.addEventListener("click", () => {
    sjekkSvr(quizdata, svr, quiznr);
    document.getElementById("alt1").style.backgroundColor = "#ffffff";
    document.getElementById("alt2").style.backgroundColor = "#ffffff";
    document.getElementById("alt3").style.backgroundColor = "#ffffff";
    document.getElementById("alt4").style.backgroundColor = "#ffffff";
    document.getElementById("alt5").style.backgroundColor = "#ffffff";
    document.getElementById("alt6").style.backgroundColor = "#ffffff";
})

// Oppdater quiz med neste spoersmaal hvis du trykker "Neste"
var i = 0;
var L = 4;

neste.addEventListener("click", () => {
    i++;
    quiznr = oppdaterQuiz(quizdata, i);
    svr = 0;
    if (riktig == 1){
        if (i == 1){
            salt1.style.height = "60px";
        }
        if (i == 2){
            salt2.style.height = "60px";
        }
        if (i == 3){
            salt3.style.height = "60px";
        }
        if (i == 4){
            salt4.style.height = "60px";
        }
        if (i >= L){
            boks.style.display = 'none';
            document.getElementById('resultat').innerHTML = poeng;
            slutt.style.display = 'flex';
            boks2.style.display = 'flex';
        }
        riktig = 0;
    }
})

document.getElementById('resultat').addEventListener("click", () => {
    if (quiznr >= L) {
        document.getElementById('resultat').innerHTML = poeng;
        console.log(poeng);
    }
})
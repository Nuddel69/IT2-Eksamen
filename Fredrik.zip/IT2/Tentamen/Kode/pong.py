# importerer turtle biblioteket
import turtle

# genererer skjermen
sk = turtle.Screen()
sk.title("Pong spill")
sk.bgcolor("black")
sk.setup(width=1000, height=600)

# rekkert
r = turtle.Turtle()
r.speed(0)
r.shape("square")
r.color("white")
r.shapesize(stretch_wid=2, stretch_len=6)
r.penup()
r.goto(0, -200)

# hindring
h = turtle.Turtle()
h.speed(0)
h.shape("square")
h.color("white")
h.shapesize(stretch_wid=4, stretch_len=6)
h.penup()
h.goto(0, 100)
hdx = 0

# Ball
ball = turtle.Turtle()
ball.speed(40)
ball.shape("circle")
ball.color("white")
ball.penup()
ball.goto(0, 0)
ball.dx = 6
ball.dy = -9.81


spiller = 0

# viser poengene
poeng = turtle.Turtle()
poeng.speed(0)
poeng.color("white")
poeng.penup()
poeng.hideturtle()
poeng.goto(0, 260)
poeng.write("Poeng : 0", align="center", font=("Courier", 24, "normal"))


# bevede racketten
def rackettvenstre():
    x = r.xcor()
    x -= 20
    r.setx(x)


def racketthøyre():
    x = r.xcor()
    x += 20
    r.setx(x)


while True:
    sk.listen()
    sk.onkeypress(rackettvenstre, "Left")
    sk.onkeypress(racketthøyre, "Right")

    sk.update()

    ball.setx(ball.xcor() + ball.dx)
    ball.sety(ball.ycor() + ball.dy)

    ball.dy = ball.dy - 0.3

    if h.xcor() > 400:
        hdx = -1
    elif h.xcor() < -400:
        hdx = 1

    hx = h.xcor()
    hx += hdx
    h.setx(hx)

    # Checking borders
    if ball.ycor() > 280:
        ball.sety(280)
        ball.dy *= -1

    if ball.ycor() < -280:
        tapte = True

    if ball.xcor() > 480:
        ball.setx(480)
        ball.dx *= -1

    if ball.xcor() < -480:
        ball.setx(-480)
        ball.dx *= -1

    # ball kollision

    if (ball.ycor() < -175 and ball.ycor() > -185) and (ball.xcor() < r.xcor() + 75 and ball.xcor() > r.xcor() - 75):
        ball.sety(-175)
        ball.dy = 15
        spiller += 1
        poeng.clear()
        poeng.write("Poeng : {} ".format(
            spiller), align="center",
            font=("Courier", 24, "normal"))

    if (ball.ycor() > 50 and ball.ycor() < 60) and (ball.xcor() < h.xcor() + 80 and ball.xcor() > h.xcor() - 80):
        ball.sety(50)
        ball.dy *= -1

    if (ball.ycor() > 50 and ball.ycor() < 150) and (ball.xcor() < h.xcor() + 75 and ball.xcor() > h.xcor() + 65):
        ball.setx(75)
        ball.dx *= -1

    if (ball.ycor() < 150 and ball.ycor() > 140) and (ball.xcor() < h.xcor() + 80 and ball.xcor() > h.xcor() - 80):
        ball.sety(150)
        ball.dy *= -1

    if (ball.ycor() > 50 and ball.ycor() < 150) and (ball.xcor() > h.xcor() - 75 and ball.xcor() < h.xcor() - 65):
        ball.setx(-75)
        ball.dx *= -1

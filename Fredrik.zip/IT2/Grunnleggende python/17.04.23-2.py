# Videreføring av If

tekst = input()
if 'Hei' in tekst:
    print('ja')

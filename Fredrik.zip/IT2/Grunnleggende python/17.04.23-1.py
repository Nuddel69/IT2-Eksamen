# Her skal vi skrive vår første kode:-)

print('Hei, hva heter du?')
navn = input()
if navn ==  '':
    print('Du trykket "Enter" uten å skrive navnet ditt')
else:
    print('Hei ' + navn + '! Velkommen til python!')

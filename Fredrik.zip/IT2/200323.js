class Tallfølge {
    constructor(førsteTall) {
      this.førsteTall = førsteTall;
    }
  
    aritmetiskRekke(n, differanse) {
      let tall = this.førsteTall;
      let sum = tall;
  
      for (let i = 1; i < n; i++) {
        tall += differanse;
        sum += tall;
      }
  
      return sum;
    }
  
    geometriskRekke(n, forhold) {
      let tall = this.førsteTall;
      let sum = tall;
  
      for (let i = 1; i < n; i++) {
        tall *= forhold;
        sum += tall;
      }
  
      return sum;
    }
  
    divergerendeRekke() {
      let tall = this.førsteTall;
      let sum = 0;
  
      while (tall !== Infinity) {
        sum += tall;
        tall *= 2;
      }
  
      return sum;
    }
  
    konvergerendeRekke() {
      let tall = this.førsteTall;
      let sum = tall;
  
      while (tall > 0.0001) {
        tall /= 2;
        sum += tall;
      }
  
      return sum;
    }
  }
  
  let tallfølge = new Tallfølge(1);
  console.log(tallfølge.aritmetiskRekke(10, 2)); // 110
  console.log(tallfølge.geometriskRekke(10, 2)); // 1023
  console.log(tallfølge.divergerendeRekke()); // Infinity
  console.log(tallfølge.konvergerendeRekke()); // 2.0000152587890625
  
var flybutikken = {"navn":"Flybutikken","versjon":"0.1","flyer":
[{"id":"1","tittel":"Saab 29 Tunnan","poster":"Tunnan.jpg","pris":"150000000"},
{"id":"2","tittel":"Northrop F-5E TigerII","poster":"F-5.jpg","pris":"21000000"},
{"id":"3","tittel":"Gruman F-14B Tomcat","poster":"F-14.jpg","pris":"38000000"}, 
{"id":"4","tittel":"Sukhoi SU-57 Felon","poster":"SU-57.jpg","pris":"1400000000"}]};